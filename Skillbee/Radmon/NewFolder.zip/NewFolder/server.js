const fs = require("fs");
const axios = require("axios");
const ejs = require("ejs");
const path = require("path");
const express = require("express"); // Import Express

const app = express(); // Create an instance of Express
const baseDir = "./templates";
const templatePath = `${baseDir}/page.ejs`;

// Check if the base directory exists
if (!fs.existsSync(baseDir)) {
  console.error("Base directory does not exist:", baseDir);
  process.exit(1);
}

// Read the EJS template file
const templateContent = fs.readFileSync(templatePath, "utf-8");

async function fetchData() {
  const apiUrl = "https://www.boredapi.com/api/activity";
  try {
    const response = await axios.get(apiUrl);
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    return null;
  }
}

async function generatePages(pageCount) {
  const pages = [];

  try {
    for (let i = 1; i <= pageCount; i++) {
      const data = await fetchData();
      if (data) {
        console.log(`Page ${i} data:`, data);
        const renderedPage = ejs.render(templateContent, data); // Render the template using EJS
        pages.push({ content: renderedPage });
      }
    }

    return pages;
  } catch (error) {
    console.error("Error generating pages:", error);
    return [];
  }
}

const pageCount = 10; // Change this to 100 for generating 100 pages
generatePages(pageCount)
  .then((pages) => {
    console.log(`${pageCount} unique pages generated successfully!`);

    // Serve the public directory statically
    app.use(express.static(path.join(__dirname, "public")));

    // Handle root request with a list of clickable pages
    app.get("/", (req, res) => {
      const pageLinks = Array.from({ length: pageCount }, (_, i) => i + 1);
      const pageLinksHtml = pageLinks.map(
        (pageNum) => `<li><a href="/${pageNum}">Page ${pageNum}</a></li>`
      );

      const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Generated Pages</title>
        </head>
        <body>
          <h1>Generated Pages List:</h1>
          <ul>
            ${pageLinksHtml.join("\n")}
          </ul>
        </body>
        </html>
      `;

      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(html);
    });

    // Handle requests for individual generated pages
    app.get("/:pageId", (req, res) => {
      const pageIndex = parseInt(req.params.pageId);

      const pageData = pages[pageIndex - 1];
      if (pageData) {
        res.writeHead(200, { "Content-Type": "text/html" });
        res.end(pageData.content);
      } else {
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("Page not found.");
      }
    });

    const port = 3000;
    app.listen(port, () => {
      console.log(`Server is running at http://localhost:${port}/`);
    });
  })
  .catch((error) => {
    console.error("Error generating pages:", error);
  });
